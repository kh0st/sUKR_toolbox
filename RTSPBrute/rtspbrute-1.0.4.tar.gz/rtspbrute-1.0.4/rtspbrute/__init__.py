from pathlib import Path

__version__ = "1.0.4"
DEFAULT_ROUTES = Path(__file__).parent / "routes.txt"
DEFAULT_CREDENTIALS = Path(__file__).parent / "credentials.txt"
